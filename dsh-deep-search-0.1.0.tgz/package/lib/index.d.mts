import z from "@deepseek-ai/schemastery";
//#region src/index.d.ts
declare const name = "dsh-deep-search";
declare const inject: readonly ["tools", "systemPrompt"];
declare const ConfigSchema: z<Schemastery.ObjectS<NoInfer<{
  enabledEngines: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
  enabledPlatforms: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
  searxngInstances: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
  proxy: z<string, string, "volatile-defined">;
  proxyByTarget: z<NoInfer<import("@deepseek-ai/cosmokit").Dict<string, string>>, NoInfer<import("@deepseek-ai/cosmokit").Dict<string, string>>, "volatile-defined">;
  concurrency: z<number, number, "volatile-defined">;
  queryTimeoutMs: z<number, number, "volatile-defined">;
  maxRounds: z<number, number, "volatile-defined">;
  budgetChars: z<number, number, "volatile-defined">;
  rateLimitPerMinute: z<number, number, "volatile-defined">;
  cooldownMinutes: z<number, number, "volatile-defined">;
  cacheTtlMinutes: z<number, number, "volatile-defined">;
  lruSize: z<number, number, "volatile-defined">;
  xEndpoint: z<string, string, "volatile-defined">;
  xEndpointCredentialRef: z<string, string, "volatile-defined">;
  zhihuCredentialRef: z<string, string, "volatile-defined">;
  promptInjection: z<boolean, boolean, "volatile-defined">;
  verbose: z<boolean, boolean, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
  enabledEngines: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
  enabledPlatforms: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
  searxngInstances: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
  proxy: z<string, string, "volatile-defined">;
  proxyByTarget: z<NoInfer<import("@deepseek-ai/cosmokit").Dict<string, string>>, NoInfer<import("@deepseek-ai/cosmokit").Dict<string, string>>, "volatile-defined">;
  concurrency: z<number, number, "volatile-defined">;
  queryTimeoutMs: z<number, number, "volatile-defined">;
  maxRounds: z<number, number, "volatile-defined">;
  budgetChars: z<number, number, "volatile-defined">;
  rateLimitPerMinute: z<number, number, "volatile-defined">;
  cooldownMinutes: z<number, number, "volatile-defined">;
  cacheTtlMinutes: z<number, number, "volatile-defined">;
  lruSize: z<number, number, "volatile-defined">;
  xEndpoint: z<string, string, "volatile-defined">;
  xEndpointCredentialRef: z<string, string, "volatile-defined">;
  zhihuCredentialRef: z<string, string, "volatile-defined">;
  promptInjection: z<boolean, boolean, "volatile-defined">;
  verbose: z<boolean, boolean, "volatile-defined">;
}>>, "plain">;
type LooseCtx = any;
/** apply()'s config shape — mirrors ConfigSchema (schemastery types stay host-side). */
interface PluginConfig {
  enabledEngines: string[];
  enabledPlatforms: string[];
  searxngInstances: string[];
  proxy: string;
  proxyByTarget: Record<string, string>;
  concurrency: number;
  queryTimeoutMs: number;
  maxRounds: number;
  budgetChars: number;
  rateLimitPerMinute: number;
  cooldownMinutes: number;
  cacheTtlMinutes: number;
  lruSize: number;
  xEndpoint: string;
  xEndpointCredentialRef: string;
  zhihuCredentialRef: string;
  promptInjection: boolean;
  verbose: boolean;
}
declare function apply(ctx: LooseCtx, rawConfig: PluginConfig): void;
declare const _default: {
  name: string;
  inject: readonly ["tools", "systemPrompt"];
  Config: z<Schemastery.ObjectS<NoInfer<{
    enabledEngines: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
    enabledPlatforms: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
    searxngInstances: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
    proxy: z<string, string, "volatile-defined">;
    proxyByTarget: z<NoInfer<import("@deepseek-ai/cosmokit").Dict<string, string>>, NoInfer<import("@deepseek-ai/cosmokit").Dict<string, string>>, "volatile-defined">;
    concurrency: z<number, number, "volatile-defined">;
    queryTimeoutMs: z<number, number, "volatile-defined">;
    maxRounds: z<number, number, "volatile-defined">;
    budgetChars: z<number, number, "volatile-defined">;
    rateLimitPerMinute: z<number, number, "volatile-defined">;
    cooldownMinutes: z<number, number, "volatile-defined">;
    cacheTtlMinutes: z<number, number, "volatile-defined">;
    lruSize: z<number, number, "volatile-defined">;
    xEndpoint: z<string, string, "volatile-defined">;
    xEndpointCredentialRef: z<string, string, "volatile-defined">;
    zhihuCredentialRef: z<string, string, "volatile-defined">;
    promptInjection: z<boolean, boolean, "volatile-defined">;
    verbose: z<boolean, boolean, "volatile-defined">;
  }>>, Schemastery.ObjectT<NoInfer<{
    enabledEngines: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
    enabledPlatforms: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
    searxngInstances: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
    proxy: z<string, string, "volatile-defined">;
    proxyByTarget: z<NoInfer<import("@deepseek-ai/cosmokit").Dict<string, string>>, NoInfer<import("@deepseek-ai/cosmokit").Dict<string, string>>, "volatile-defined">;
    concurrency: z<number, number, "volatile-defined">;
    queryTimeoutMs: z<number, number, "volatile-defined">;
    maxRounds: z<number, number, "volatile-defined">;
    budgetChars: z<number, number, "volatile-defined">;
    rateLimitPerMinute: z<number, number, "volatile-defined">;
    cooldownMinutes: z<number, number, "volatile-defined">;
    cacheTtlMinutes: z<number, number, "volatile-defined">;
    lruSize: z<number, number, "volatile-defined">;
    xEndpoint: z<string, string, "volatile-defined">;
    xEndpointCredentialRef: z<string, string, "volatile-defined">;
    zhihuCredentialRef: z<string, string, "volatile-defined">;
    promptInjection: z<boolean, boolean, "volatile-defined">;
    verbose: z<boolean, boolean, "volatile-defined">;
  }>>, "plain">;
  apply: typeof apply;
};
//#endregion
export { ConfigSchema, apply, _default as default, inject, name };
//# sourceMappingURL=index.d.mts.map